<?

$deviceid = "xxxxxxxx";
$token = "r:xxxxxxxx";
$appid = "xxxxxxxx";
$installid = "xxxxxxxxx";
$clientkey = "xxxxxxxx";